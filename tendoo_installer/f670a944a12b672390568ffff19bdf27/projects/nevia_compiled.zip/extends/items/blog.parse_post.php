<section>
  <h4><?php echo $this->tendoo->getTitle();?></h4>
  	<?php		if(count($this->blogPost) > 0)		{	?>
  		<?php foreach($this->blogPost as $p){	
			$global	=	$this->tendoo->time($p['TIMESTAMP'],TRUE); 
			$base		=	$this->tendoo->time($p['TIMESTAMP']);
		?>
  		<articles>
          <h3><a href="<?php echo $p['LINK'];?>"><?php echo $p['TITLE'];?></a></h3>
          <img src="<?php echo $p['THUMB'];?>">
          <p><?php echo word_limiter(strip_tags($p['CONTENT']),400);?></p>
          <span> le <?php echo $base;?></span>
          <ul>
          <?php foreach($p['CATEGORIES'] as $category_child){ ?>
            <li><a href="<?php echo $category_child['LINK'];?>"><?php echo $category_child['TITLE'];?></a></li>
          <?php } ?>
          </ul>
          <?php if(is_array($p['KEYWORDS']) && count($p['KEYWORDS']) > 0){ ?>
          <span>Mots clés</span>
          <ul>
            <?php foreach($p['KEYWORDS'] as $keywords){ ?>
            	<li><a href="<?php echo $keywords['LINK']; ?>"><?php echo $keywords['TITLE']; ?></a></li>
            <?php } ?>            
          </ul>
          <?php } ?>
  		</articles>
  		<?php 		} ?>
  	<?php	}		else if($this->blogPost === FALSE)		{			?>
	<div>Aucun article disponible</div>
  	<?php		} ?>
</section>