<section class="wrapper">
	<aside>
		<?php echo $this->parseRightWidgets();?>
	</aside>
    <section>
        <?php $this->parseSingleBlogPost();?>
        <?php $this->parseBlogPost();?>
    </section>
    <aside>
    	<?php echo $this->parseLeftWidgets();?>
    </aside>
</section>
