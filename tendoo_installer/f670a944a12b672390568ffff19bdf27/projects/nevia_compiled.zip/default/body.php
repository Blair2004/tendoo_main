<body>
  	<div id="wrapper">
		<?php echo $header;?>
  	</div>
</body>
</html>