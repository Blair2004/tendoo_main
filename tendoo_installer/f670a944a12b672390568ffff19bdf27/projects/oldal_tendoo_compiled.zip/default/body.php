<body>
  <div class="main-wrap">
	<?php echo $header;?>
	<?php echo $module_content;?>
	<?php echo $footer;?>
  </div>
  
</body>
</html>