<?php $this->installSession();
$this->appType('THEME');
$this->appVers(0.1);
$this->appTendooVers(0.98);
$this->appTableField(array(
	'NAMESPACE'		=> "oldal_tendoo",
	'HUMAN_NAME'	=> "oldal_tendoo",
	'AUTHOR'		=> "admin",
	'DESCRIPTION'	=> "Thème sans description",
	'TENDOO_VERS'	=> 0.98 
));