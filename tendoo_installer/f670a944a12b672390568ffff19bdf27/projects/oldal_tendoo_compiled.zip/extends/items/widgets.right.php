<aside class="widgets">
  <?php if(count($this->ttRightWidgets) > 0){ ?>
  	<?php foreach($this->ttRightWidgets as $w)		{ ?>
  <div class="widget list">
    <h3><?php echo $w['TITLE'];?></h3>
    <?php echo $w['CONTENT'];?>
  </div>
  	<?php } ?>
  <?php } ?>
</aside>