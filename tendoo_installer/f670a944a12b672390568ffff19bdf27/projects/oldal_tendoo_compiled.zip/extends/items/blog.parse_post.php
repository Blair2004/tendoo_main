<section class="posts">
    <div class="container">
        <div class="row">
            <div class="col-sm-9">
              <?php		if(count($this->blogPost) > 0)		{	?>
              	<?php foreach($this->blogPost as $p){	
			$global	=	$this->tendoo->time($p['TIMESTAMP'],TRUE); 
			$base		=	$this->tendoo->time($p['TIMESTAMP']);
		?>
                <article class="post">
                    <h3><?php echo $p['TITLE'];?></h3>
                    <ul class="info">
                        <li>
                            <div class="text date"><?php echo $base;?></div>
                        </li>
                    </ul>
                    <figure> <a href="<?php echo $p['LINK'];?>"><img src="<?php echo $p['THUMB'];?>" alt="img"></a> </figure>
                    <div class="content"> <?php echo word_limiter(strip_tags($p['CONTENT']),100);?></div>
                    <div class="btn btn-default"><a href="<?php echo $p['LINK'];?>">Lire la suite</a></div>
                </article>
              	<?php 		} ?>
              <?php	}		else if($this->blogPost === FALSE)		{			?>
              <h5>Aucun article disponible</h5>
              <?php		} ?>
                <div class="older-posts text-right">
                    <div class="btn btn-primary">Older Articles</div>
                </div>
            </div>
            <div class="col-md-1 hidden-sm"></div>
            <div class="col-md-2 col-sm-3">
                <?php echo $this->parseRightWidgets();?>
            </div>
        </div>
    </div>
</section>

