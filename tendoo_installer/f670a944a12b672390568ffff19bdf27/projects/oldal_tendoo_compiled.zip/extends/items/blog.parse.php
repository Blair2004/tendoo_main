<section class="line top">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="col-md-4 col-sm-5 col-xs-12">
                    <div class="title">
                        <?php echo $this->tendoo->getTitle();?>
                        <ul class="current-page">
                            <li>Home</li>
                            <li>></li>
                            <li>Blog</li>
                            <li>></li>
                            <li>Blog w/ Sidebar</li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-8 col-sm-7 col-xs-12">
                    <div class="title-content">
                        <?php echo $this->tendoo->getDescription();?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $this->parseBlogPost();?>
<?php $this->parseSingleBlogPost();?>