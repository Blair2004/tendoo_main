<?php 
class oldal_tendoo_theme_library
{
	public function __construct($data)
	{
		__extends($this);
	}
}