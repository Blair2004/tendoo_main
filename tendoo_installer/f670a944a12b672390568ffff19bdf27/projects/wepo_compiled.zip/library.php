<?php 
class wepo_theme_library
{
	public function __construct($data)
	{
		__extends($this);
	}
}