<?php echo current_user("menu"); ?>
<header <?php echo current_user("isconnected") ? 'style="margin-top:30px"' : '';?>>
	<h3><img src="<?php echo $options[0]['SITE_LOGO'];?>" alt="<?php echo $options[0]['SITE_NAME'];?>"></h3>
    <ul>
    	<?php foreach($controllers as $c)	{ ?>
        	<?php if($c["PAGE_CNAME"] == $this->url->controller())	{ ?>
                <?php if($c["PAGE_MODULES"] == "#LINK#")	{ ?>
                <li class="active"><a href="<?php echo $c["PAGE_LINK"];?>" title="<?php echo $c["PAGE_TITLE"];?>"><?php echo ucwords($c["PAGE_NAMES"]);?></a><?php $this->tendoo->getControllerSubmenu($c);?></li>
                <?php } else { ?>
                <li class="active"><a href="<?php echo $this->url->site_url(array($c["PAGE_CNAME"]));?>" title="<?php echo $c["PAGE_TITLE"];?>"><?php echo ucwords($c["PAGE_NAMES"]);?></a><?php $this->tendoo->getControllerSubmenu($c);?></li>
                <?php } ?>
			<?php } else { ?>
            	<?php if($c["PAGE_MODULES"] == "#LINK#")	{ ?>
                <li class="active"><a href="<?php echo $c["PAGE_LINK"];?>" title="<?php echo $c["PAGE_TITLE"];?>"><?php echo ucwords($c["PAGE_NAMES"]);?></a><?php $this->tendoo->getControllerSubmenu($c);?></li>
                <?php } else { ?>
                <li class=""><a href="<?php echo $this->url->site_url(array($c["PAGE_CNAME"]));?>" title="<?php echo $c["PAGE_TITLE"];?>"><?php echo ucwords($c["PAGE_NAMES"]);?></a><?php $this->tendoo->getControllerSubmenu($c);?></li>
                <?php } ?>
            <?php } ?>                
        <?php } ?>
    </ul>
</header>