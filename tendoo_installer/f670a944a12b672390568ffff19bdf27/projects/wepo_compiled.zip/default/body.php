<section>
	<?php echo $header;?>
    <?php echo $module_content;?>
    <?php echo $footer;?>
</section>
</html>