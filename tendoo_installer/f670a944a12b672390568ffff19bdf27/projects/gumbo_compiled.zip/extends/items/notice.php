<?php if(strlen($this->notice->parse_notice()) > 0)	{	?>
<div>
  <p><?php $this->notice->parse_notice();?></p>
</div>
<?php	} ?>