<section> <?php if(count($this->singleBlogPost) > 0)		{	
			$global	=	$this->tendoo->time($this->singleBlogPost['TIMESTAMP'],TRUE); 
			$base		=	$this->tendoo->time($this->singleBlogPost['TIMESTAMP']);
		?>
    <article>
        <h3><?php echo $this->singleBlogPost['TITLE'];?></h3>
        <img src="<?php echo $this->singleBlogPost['FULL'];?>" alt="<?php echo $this->singleBlogPost['TITLE'];?>"> 
      <small>par <a href="<?php echo $this->url->site_url(array('account','profile',$this->singleBlogPost['AUTHOR']['PSEUDO']));?>"><?php echo $this->singleBlogPost['AUTHOR']['PSEUDO'];?></a></small> 
      <?php foreach($this->singleBlogPost['CATEGORIES'] as $category_child){ ?> 
      	<small>dans 
          <a href="<?php echo $category_child['LINK'];?>"><?php echo $category_child['TITLE'];?></a>, 
      </small> 
      <?php } ?> 
      <small> mot clé</small> 
      	<?php if(is_array($this->singleBlogPost['KEYWORDS']) && count($this->singleBlogPost['KEYWORDS']) > 0){ ?>
        <ul>
            <?php foreach($this->singleBlogPost['KEYWORDS'] as $keywords){ ?>
            <li><a href="<?php echo $keywords['LINK']; ?>"><?php echo $keywords['TITLE']; ?></a></li>
            <?php } ?>
        </ul>
        <?php } ?>
        <p><?php echo $this->singleBlogPost['CONTENT'];?></p>
    </article>
    <div id="comments">
        <h4><?php echo $this->TT_SBP_comments;?> commentaire(s)</h4>
        <?php	if($this->TT_SBP_comments > 0)			{ ?>
        <ul>
            <?php $commentID	=	1;	foreach($this->SBP_comments as $s)	{ ?>
          <li> <span><a href="#"><?php echo $s['AUTHOR']['PSEUDO'] ;?></a> <?php echo $s['TIMESTAMP'];?></span><p><?php echo $s['CONTENT'];?></p></li>
            <?php };?>
        </ul>
      	<?php	} else { ?>
      <h5>Aucune commentaire disponible</h5>
        <?php	};?> 
      
  	</div>
  		<?php $this->parseNotice();?>
  		<?php $this->parseForm();?>
    <?php		}		else if($this->singleBlogPost	===	false)		{			?>
    <h3>article introuvable</h3>
    <?php 	} ?> 
</section>
