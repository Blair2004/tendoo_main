<footer>
	<div class="col-lg-4">
    	<?php echo $this->parseBottomWidgets();?>
    </div>
    <div class="col-lg-4">
    	<?php echo $this->tendoo->getVersion();?>
    </div>
</footer>