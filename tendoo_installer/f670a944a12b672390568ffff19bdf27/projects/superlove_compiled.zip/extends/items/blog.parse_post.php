<section>
  	<?php		if(count($this->blogPost) > 0)		{	?>
  		<?php foreach($this->blogPost as $p){	?>
  		<articles>
          <h3><a href="<?php echo $p['LINK'];?>"><?php echo $p['TITLE'];?></a></h3>
          <img src="<?php echo $p['THUMB'];?>">
          <p><?php echo word_limiter(strip_tags($p['CONTENT']),400);?></p>
          <ul>
          <?php foreach($p['CATEGORIES'] as $category_child){ ?>
            <li><a href="<?php echo $category_child['LINK'];?>"><?php echo $category_child['TITLE'];?></a></li>
          <?php } ?>
          </ul>
  		</articles>
  		<?php 		} ?>
  	<?php	}		else if($this->blogPost === FALSE)		{			?>
	<div>Aucun article disponible</div>
  	<?php		} ?>
</section>