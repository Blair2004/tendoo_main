<?php 
class superlove_theme_library
{
	public function __construct($data)
	{
		__extends($this);
	}
}